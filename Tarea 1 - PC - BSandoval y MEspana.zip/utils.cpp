#include <stdio.h>
#include <time.h>
#include "utils.h"

// Función para obtener el tiempo transcurrido en nanosegundos
unsigned long long nanos() {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC_RAW, &t);  // Usar CLOCK_MONOTONIC_RAW para una alta precisión
    return (unsigned long long)t.tv_sec * 1000000000ULL + (unsigned long long)t.tv_nsec;
}

void delayNanos(unsigned long long ns){
    unsigned long long startTime=nanos();
    while(nanos()-startTime<ns);
}