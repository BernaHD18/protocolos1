#include <stdio.h>
#include <wiringPi.h>
#include "utils.h"
#include "colas.h"
#include "SoftClock.h"
#include "paquete.h"

#define TX_PIN 23
#define RX_PIN 18
#define CLOCK_PIN 16        // Puentiado a PIN DE RELOJ
#define PIN_CLOCK 20
#define BYTE unsigned char
#define SPEED 10

volatile Cola buffE;
volatile Cola buffR;

BYTE readBufferedByte(volatile Cola & buff);
void writeBufferedByte(volatile Cola & buff, BYTE byte);
bool reciveByte(int pin, int speed, BYTE* byte);
void send();

volatile int nBits = 0;
volatile BYTE byte = 0;

SoftClock clock(PIN_CLOCK, SPEED,false);
PI_THREAD (reloj){
        clock.run();
}
PI_THREAD (read){
        while(true){
            BYTE byte = 0;
            reciveByte(RX_PIN, SPEED, &byte);
            writeBufferedByte(buffR, byte);
        }
}

int main(int argc , char * argv []){
    if(wiringPiSetupGpio()==-1) {
        printf("ERROR");
        return 0;
    }
    crearCola((Cola&)buffE);
    crearCola((Cola&)buffR);
    pinMode(TX_PIN, OUTPUT);
    digitalWrite(TX_PIN, HIGH); // inicializa línea en reposo
    pinMode(RX_PIN, INPUT);
    piThreadCreate (reloj);
    piThreadCreate (read);

    // CONFIGURA INTERRUPCION CLOCK_PIN (PUENTEADO A PIN_CLOCK)
    if (wiringPiISR(CLOCK_PIN, INT_EDGE_BOTH, &send) < 0){
        printf("Unable to start interrupt function\n");
    }
    
    int n=1;
    while(n<=10000){
        paquete PKG;
        printf("Esperando información\n");
        fflush(stdout);
        int i=0;
        while(vacia(buffR)){
            delay(4000);
        }
        while(!vacia(buffR)){
            BYTE byte = readBufferedByte(buffR); // función bloqueante
            PKG.frame[i] = byte;
            i++;
        }
        while(!vacia(buffR)){
            delay(2000);
        }
        PKG.desempaqueta(); // Desempaquetado de datos recibidos
        printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu  |  CKSM=%d\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
        fflush(stdout);
        
        PKG.cmd= 3;     // Cambio de comando 
        PKG.empaqueta();  	// Empaquetado de datos
        int largoEnv= PKG.size();
        printf("Enviando respuesta...\n");
        printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu |  CKSM=%d\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
        fflush(stdout);
        for(int i=0;i<largoEnv;i++){
            BYTE byte = PKG.frame[i];
            writeBufferedByte(buffE, byte);
        }
        if(PKG.cmd==66){
            printf("Orden final recibida. Cerrando...");
            return 0;
        }

        while(!vacia(buffE)){
            delay(2000); // tiempo necesario para asegurar el envío del último byte
        }
              
        printf("--------\n");
    }
    return 0;


}





void send(){
    if(nBits == 0){
        if(!vacia(buffE)){
            byte = readBufferedByte(buffE);
            digitalWrite(TX_PIN, LOW); //bit de comienzo	-> 0
            nBits++;
        }else{
            digitalWrite(TX_PIN, HIGH); // Si no hay nada que enviar, canal en reposo
        }
    }else if(nBits < 9){
        digitalWrite(TX_PIN, (byte >> (nBits-1)) & 0x01); //Bit de dato
        nBits++;
    }else if(nBits == 9){
        int paridad = (byte>>0&0x01) + (byte>>1&0x01) + (byte>>2&0x01) + (byte>>3&0x01) +
                      (byte>>4&0x01) + (byte>>5&0x01) + (byte>>6&0x01) + (byte>>7&0x01);
        digitalWrite(TX_PIN, paridad%2==0); //Bit de paridad
        nBits++;
    }else{
        digitalWrite(TX_PIN, HIGH); //Canal libre durante 2 clocks
        nBits++;
    }
    if(nBits == 11){
        nBits = 0;
        byte = 0;
    }
}

bool reciveByte(int pin, int speed, BYTE* byte){
    unsigned long long microSeg = 1E6/speed;
    *byte = 0;
    bool level = HIGH;
    while(level==HIGH){//linea en reposo
        level = digitalRead(pin);
    }
    delayMicroseconds(microSeg*1.5); //espera un bit y medio
    int paridad = 0;
    for(int i=0; i<8; i++) {
        level = digitalRead(pin); // HIGH=1, LOW=0
        if(level)
            paridad++;
        *byte = *byte | (level<<i);
        delayMicroseconds(microSeg); //espera un bit
    }
    level = digitalRead(pin);//Lee bit de paridad
    bool levelPar = level;
    while(level == LOW) //lee o consume el bit de paridad hasta que comienza el bit de parada (recincroniza)
        level = digitalRead(pin);
    if(paridad%2 == levelPar)
        return true;
    return false;
}

void writeBufferedByte(volatile Cola & buff, BYTE byte){
    ponerEnCola(byte,(Cola&)buff);
}
BYTE readBufferedByte(volatile Cola & buff){
    while(vacia(buff));
    BYTE byte = frente(buff);
    quitarDeCola((Cola&)buff);
    return byte;
}