#include "Estadistica.h"

// Constructor para inicializar valores
Estadistica::Estadistica(){
    n = 0;
    media=0;
    M2=0;
}

// Función para agregar un nuevo dato
void Estadistica::addData(double nuevoDato) {
    data[n] = nuevoDato;
    n += 1;
    double delta = nuevoDato - media;
    media += delta / n;
    double delta2 = nuevoDato - media;
    M2 += delta * delta2;
}

// Función para obtener la varianza muestral
double Estadistica::getVariance() {
    if (n < 2) {
        return NAN;  // La varianza no está definida para menos de 2 datos
    }
    return M2 / (n - 1);
}

// Función para obtener la desviación estándar
double Estadistica::getSD() {
    return sqrt(getVariance());
}

// Función para obtener la media actual
double Estadistica::getAverage() {
    return media;
}

// Función para obtener el número de datos procesados
unsigned long long Estadistica::getN() {
    return n;
}

double Estadistica::getData(int i){
    return data[i];
}