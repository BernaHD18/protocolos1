#ifndef ESTADISTICA_H
#define ESTADISTICA_H

#include <math.h>  // Para sqrt()

class Estadistica {
private:
    unsigned long long n;           // Contador de datos
    double media;    // Media acumulada
    double M2;       // Suma de los cuadrados de las diferencias respecto a la media
    double data[10000];

public:
    // Constructor para inicializar valores
    Estadistica();
    // Función para agregar un nuevo dato
    void addData(double nuevoDato);
    double getData(int i);
    // Función para obtener la varianza muestral
    double getVariance();
    // Función para obtener la desviación estándar
    double getSD();
    // Función para obtener la media actual
    double getAverage();
    // Función para obtener el número de datos procesados
    unsigned long long getN();
};

#endif