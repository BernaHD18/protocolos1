#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include "utils.h"
#include "SoftClock.h"
#include <unistd.h>


SoftClock::SoftClock(int pinClock, int speed, bool runStats){
	if (wiringPiSetupGpio() == -1) {
		printf ( " ERROR " ) ;
	}
    startTime = 0;
    this->runStats = runStats;
    this->pinClock = pinClock;
    this->speed = speed;
    nanoSeg = 1E9/speed;
    isRuning = false;
	pinMode( pinClock , OUTPUT );
}

void SoftClock::run(){
    start();
    unsigned long long microSeg = 1E6/speed;
    if(runStats){
        printf("Iniciando reloj con parámetros bit: %llu[us], %d[Hz] \n", microSeg, this->speed );
        fflush(stdout);
    }
    double bitTime=0;
    state = HIGH;
    while ( true ) {
        unsigned long long ini = nanos();
        if(isRuning){
            state = !state;
            digitalWrite (pinClock , state );
		    //delayNanos( nanoSeg );
            //usleep(microSeg);
            delayMicroseconds(microSeg);
            if(runStats){
                bitTime = (nanos() - ini)/1000.0d; // duración en microseg
                if(stats.getN() < 10 || (fabs(bitTime - stats.getAverage()) < stats.getSD() * 5)){
                    stats.addData(bitTime);
                }else{
                    error.addData(bitTime);
                }
            }
        }
    }
}
unsigned long long SoftClock::getBitTime(){
    return nanoSeg;
}
int SoftClock::getTime(){
    if(startTime == 0)
        return 0;
    else{
        return (nanos()-startTime)/1E9;
    }
}
void SoftClock::synchronize(){
    unsigned long long microSeg = (1E6/speed)*1.5d; // espera medio bit
    state = !state;
    digitalWrite(pinClock , state );
    delayMicroseconds(microSeg);
}
void SoftClock::start(){
    startTime = nanos();
    this->isRuning = true;
}
void SoftClock::stop(){
    this->isRuning = false;
}
Estadistica SoftClock::getStats(){
    return stats;
}
Estadistica SoftClock::getError(){
    return error;
}