#include <stdio.h>

unsigned long long nanos();
void delayNanos(unsigned long long);