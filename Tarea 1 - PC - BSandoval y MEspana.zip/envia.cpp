#include <stdio.h>
#include <wiringPi.h>
#include <string.h>
#include "utils.h"
#include "colas.h"
#include "SoftClock.h"
#include "paquete.h"

#define TX_PIN 17
#define RX_PIN 27
#define CLOCK_PIN 19        // Puentiado a PIN DE RELOJ
#define PIN_CLOCK 26
#define BYTE unsigned char
#define SPEED 10

volatile Cola buffE;
volatile Cola buffR;

BYTE readBufferedByte(volatile Cola & buff);
void writeBufferedByte(volatile Cola & buff, BYTE byte);
bool reciveByte(int pin, int speed, BYTE* byte);
int enviarNVeces ( unsigned short int argc , char argv []);
int enviarYContar ( unsigned short int argc , char argv []);
//void procesarMensajeRecibido(int l, char data[l], int cksm);
void send();

volatile int nBits = 0;
volatile BYTE byte = 0;

int recibidosCorrectamente = 0;
int recibidosConError = 0;
int erroresNoDetectados = 0;
int totalBits = 0;
int bitsErroneos = 0;

SoftClock clock(PIN_CLOCK, SPEED,false);
PI_THREAD (reloj){
        clock.run();
}
PI_THREAD (read){
        while(true){
            BYTE byte = 0;
            reciveByte(RX_PIN, SPEED, &byte);
            writeBufferedByte(buffR, byte);
        }
}

char texto[15]="Hola mundo XDD";    // Texto de prueba
int opcion;
int main(){
    printf("Escoja una opción:\n");
    printf("1) Enviar un mensaje por defecto\n");
    printf("2) Enviar un mensaje personalizado\n");
    printf("3) Enviar un mensaje por defecto y mostrar estadística\n");
    printf("4) Terminar todos los procesos\n");
    printf("Su elección (Ingrese un único número):    ");
    scanf("%d", &opcion);
    printf("-------\n");

    paquete killPKG;
    switch(opcion){
        case 1:
            enviarNVeces(10000, texto);    // Enviar 10 veces el mensaje de prueba
            break;
        case 2:
            unsigned short int veces; int l;
            printf("Ingrese el tamaño máximo de su mensaje. \n");
            scanf("%d", &l);
            char mensaje[l];
            printf("Escriba un mensaje de hasta %d caracteres SIN ESPACIOS. \n", l);
            scanf("%s", &texto);
            printf("Escriba escriba con números cuántas veces quiere repetir el mensaje\nEl límite es 65535:     ");
            scanf("%hu", &veces);
            printf("-------\n");

            enviarNVeces(veces, texto); 
            break;
        case 3:
            /*enviarYContar(10, texto);          
            printf("Número de mensajes recibidos correctamente: %d\nBER (bits erróneos/bits totales): %.2f\nNúmero de mensajes recibidos con error: %d\nNúmero de mensajes con errores no detectados: %d\n", recibidosCorrectamente, (float)bitsErroneos/10, recibidosConError, erroresNoDetectados);
            break;*/
            printf("Función en desarrollo. No disponible por el momento\n");
            break;
        case 4:
            if(wiringPiSetupGpio()==-1) {
                printf("ERROR");
                return 0;
            }
            crearCola((Cola&)buffE);
            crearCola((Cola&)buffR);
            pinMode(TX_PIN, OUTPUT);
            digitalWrite(TX_PIN, HIGH); // inicializa línea en reposo
            pinMode(RX_PIN, INPUT);
            piThreadCreate (reloj);
            piThreadCreate (read);

            // CONFIGURA INTERRUPCION CLOCK_PIN (PUENTEADO A PIN_CLOCK)
            if (wiringPiISR(CLOCK_PIN, INT_EDGE_BOTH, &send) < 0){
                printf("Unable to start interrupt function\n");
            }
            killPKG.cmd=66; killPKG.data[1]=66;
            killPKG.l=1;
            killPKG.op=66;
            killPKG.pnum=66;
            killPKG.cksm=66;
            fflush(stdout);
            for(int i=0;i<killPKG.size();i++){
                BYTE byte = killPKG.frame[i];
                writeBufferedByte(buffE, byte);
            }
            killPKG.empaqueta();  	            
            printf("Terminando procesos...");
            fflush(stdout);
            while(!vacia(buffE)){
                delay(2000); // tiempo necesario para asegurar el envío del último byte
            }
            break;
        default:
            break;
    }

    return 0;
}



int enviarNVeces ( unsigned short int argc , char argv []) {

    if(wiringPiSetupGpio()==-1) {
        printf("ERROR");
        return 0;
    }
    crearCola((Cola&)buffE);
    crearCola((Cola&)buffR);
    pinMode(TX_PIN, OUTPUT);
    digitalWrite(TX_PIN, HIGH); // inicializa línea en reposo
    pinMode(RX_PIN, INPUT);
    piThreadCreate (reloj);
    piThreadCreate (read);

    // CONFIGURA INTERRUPCION CLOCK_PIN (PUENTEADO A PIN_CLOCK)
    if (wiringPiISR(CLOCK_PIN, INT_EDGE_BOTH, &send) < 0){
        printf("Unable to start interrupt function\n");
    }
    int n=1;
    while (n<=argc){
    // Sección de texto de prueba
    paquete PKG;
    PKG.cmd=50;
    PKG.l=strlen(argv)+1;
    PKG.op=30;
    PKG.pnum=n;
    PKG.cksm=152;
    for (int i=0; i<PKG.l; i++){
        PKG.data[i]=argv[i];
    }
    PKG.empaqueta();  	// Empaquetado de datos
    int largoEnv= PKG.size();

    printf("Enviando bytes...\n");
    printf("%s\n", PKG.data);
    printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu |  CKSM=%d\n\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
    fflush(stdout);
    for(int i=0;i<largoEnv;i++){
        BYTE byte = PKG.frame[i];
        writeBufferedByte(buffE, byte);
    }

    while(!vacia(buffE)){
        delay(2000); // tiempo necesario para asegurar el envío del último byte
    }

    printf("Leyendo respuesta...\n");
    fflush(stdout);
    int i=0;
    while(!vacia(buffR)){
        BYTE byte = readBufferedByte(buffR); // función bloqueante
        PKG.frame[i] = byte;
        i++;
    }
    PKG.desempaqueta(); // Desempaquetado de datos recibidos
    printf("%s\n", PKG.data);
    printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu  |  CKSM=%d\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
    fflush(stdout);
    printf("--------\n");
    n++;
    }
    return 0;
}
/*int enviarYContar ( unsigned short int argc , char argv []) {
    if(wiringPiSetupGpio()==-1) {
        printf("ERROR");
        return 0;
    }
    crearCola((Cola&)buffE);
    crearCola((Cola&)buffR);
    pinMode(TX_PIN, OUTPUT);
    digitalWrite(TX_PIN, HIGH); // inicializa línea en reposo
    pinMode(RX_PIN, INPUT);
    piThreadCreate (reloj);
    piThreadCreate (read);

    // CONFIGURA INTERRUPCION CLOCK_PIN (PUENTEADO A PIN_CLOCK)
    if (wiringPiISR(CLOCK_PIN, INT_EDGE_BOTH, &send) < 0){
        printf("Unable to start interrupt function\n");
    }
    int n=1;
    
    while (n<=argc){
    // Sección de texto de prueba
    paquete PKG;
    PKG.cmd=50;
    PKG.l=strlen(argv)+1;
    PKG.op=30;
    PKG.pnum=n;
    PKG.cksm=152;
    for (int i=0; i<PKG.l; i++){
        PKG.data[i]=argv[i];
    }
    PKG.empaqueta();  	// Empaquetado de datos
    int largoEnv= PKG.size();

    printf("Enviando bytes...\n");
    printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu |  CKSM=%d\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
    fflush(stdout);
    for(int i=0;i<largoEnv;i++){
        BYTE byte = PKG.frame[i];
        writeBufferedByte(buffE, byte);
    }

    while(!vacia(buffE)){
        delay(2000); // tiempo necesario para asegurar el envío del último byte
    }

    printf("Leyendo respuesta...\n");
    fflush(stdout);
    int i=0;
    while(!vacia(buffR)){
        BYTE byte = readBufferedByte(buffR); // función bloqueante
        PKG.frame[i] = byte;
        i++;
    }
    PKG.desempaqueta(); // Desempaquetado de datos recibidos
    printf("CMD=%d  |  OP=%d  |  l=%d  |  PNUM=#%hu  |  CKSM=%d\n", PKG.cmd, PKG.op, PKG.l, PKG.pnum, PKG.cksm);
    fflush(stdout);
    printf("--------\n");
    n++;
    }
    procesarMensajeRecibido(PKG.l, PKG.data, PKG.cksm);
    return 0;
}*/
void send(){
    if(nBits == 0){
        if(!vacia(buffE)){
            byte = readBufferedByte(buffE);
            digitalWrite(TX_PIN, LOW); //bit de comienzo	-> 0
            nBits++;
        }else{
            digitalWrite(TX_PIN, HIGH); // Si no hay nada que enviar, canal en reposo
        }
    }else if(nBits < 9){
        digitalWrite(TX_PIN, (byte >> (nBits-1)) & 0x01); //Bit de dato
        nBits++;
    }else if(nBits == 9){
        int paridad = (byte>>0&0x01) + (byte>>1&0x01) + (byte>>2&0x01) + (byte>>3&0x01) +
                      (byte>>4&0x01) + (byte>>5&0x01) + (byte>>6&0x01) + (byte>>7&0x01);
        digitalWrite(TX_PIN, paridad%2==0); //Bit de paridad
        nBits++;
    }else{
        digitalWrite(TX_PIN, HIGH); //Canal libre durante 2 clocks
        nBits++;
    }
    if(nBits == 11){
        nBits = 0;
        byte = 0;
    }
}
bool reciveByte(int pin, int speed, BYTE* byte){
    unsigned long long microSeg = 1E6/speed;
    *byte = 0;
    bool level = HIGH;
    while(level==HIGH){//linea en reposo
        level = digitalRead(pin);
    }
    delayMicroseconds(microSeg*1.5); //espera un bit y medio
    int paridad = 0;
    for(int i=0; i<8; i++) {
        level = digitalRead(pin); // HIGH=1, LOW=0
        if(level)
            paridad++;
        *byte = *byte | (level<<i);
        delayMicroseconds(microSeg); //espera un bit
    }
    level = digitalRead(pin);//Lee bit de paridad
    bool levelPar = level;
    while(level == LOW) //lee o consume el bit de paridad hasta que comienza el bit de parada (recincroniza)
        level = digitalRead(pin);
    if(paridad%2 == levelPar)
        return true;
    return false;
}

void writeBufferedByte(volatile Cola & buff, BYTE byte){
    ponerEnCola(byte,(Cola&)buff);
}
BYTE readBufferedByte(volatile Cola & buff){
    while(vacia(buff));
    BYTE byte = frente(buff);
    quitarDeCola((Cola&)buff);
    return byte;
}

/*
void procesarMensajeRecibido(int l, char data[l], int cksm) {
    int paridad = 0;
    for (int i = 0; i < l; i++) {
        BYTE byte = data[i];
        for (int j = 0; j < 8; j++) {
            paridad += (byte >> j) & 0x01;
        }
    }
    if (paridad % 2 == cksm) {
        recibidosCorrectamente++;
    } else {
        recibidosConError++;
    }
    totalBits += l * 8;
}*/