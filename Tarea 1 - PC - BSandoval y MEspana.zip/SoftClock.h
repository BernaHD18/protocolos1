#ifndef SOFTCLOCK_H_
#define SOFTCLOCK_H_

#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include "utils.h"
#include <math.h>
#include "Estadistica.h"

class SoftClock {

private:
    int pinClock;
    int speed;
    bool runStats;
    bool state;
    unsigned long long nanoSeg;
    unsigned long long startTime;
    volatile bool isRuning;
    Estadistica stats;
    Estadistica error;

public:
    SoftClock(int pinClock, int speed, bool runStats);
    void run();
    void start();
    void stop();
    int getTime();
    unsigned long long getBitTime();
    void synchronize();
    Estadistica getStats();
    Estadistica getError();
};

#endif /* SOFTCLOCK_H_ */