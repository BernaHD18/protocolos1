#define tipoElemento unsigned char
/*
//EJEMPLO: forma de uso.
int main(){
    cola c;
    //inicializa cola
    crearCola(c);
    ponerEnCola(2,c);
    ponerEnCola(7,c);
    ponerEnCola(3,c);
    ponerEnCola(1,c);
    ponerEnCola(8,c);
    while(!vacia(c)){
        printf("%d\n",frente(c));
        quitarDeCola(c);    
    }
    ponerEnCola(2,c);
    ponerEnCola(7,c);
    ponerEnCola(3,c);
    anula(c);
    quitarDeCola(c);  
    system("pause");
    return 0;
}
*/

//Estructuras
struct tipoCelda
{	
	tipoElemento elemento;
	tipoCelda *next;
};

struct Cola
{	
	tipoCelda *ant,*post;
};

//prototipos
void error(char *texto);
void anula(Cola &c);
bool vacia(Cola c);
tipoElemento frente(Cola c);
void ponerEnCola(tipoElemento x, Cola &c);
void quitarDeCola(Cola &c);
void crearCola(Cola &c);

//implementaciones
void crearCola(Cola &c){
    c.ant = new tipoCelda;
	c.ant->next = NULL;
	c.post = c.ant;
}
void anula(Cola &c){
    while(!vacia(c))
        quitarDeCola(c);
}

bool vacia(Cola c)
{	return c.ant == c.post;
}

tipoElemento frente(Cola c)
{	if(vacia(c))
	{	
		printf("La cola esta vacia");
   		return(0);
	}
	else
   		return c.ant->next->elemento;
}

void ponerEnCola(tipoElemento x, Cola &c)
{	
	c.post->next = new tipoCelda;
	c.post = c.post->next;
	c.post->elemento = x;
	c.post->next = NULL;
}

void quitarDeCola(Cola &c){	
	if(vacia(c))
		printf("La cola esta vacia");
	else{
        tipoCelda* aux;
        aux = c.ant;
   		c.ant = c.ant->next;
   		aux->next=NULL;
   		delete aux;
    }
}
